<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = '1520157274969349';
$config['secret']  = '9f48f101bfa688b9c45c6cec92d755bd';

?>
