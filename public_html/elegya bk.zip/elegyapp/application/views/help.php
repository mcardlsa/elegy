<div class="row">
	
	<div class="width">

    	<div class="inner_mid mar_tp_230">
        
        	<div class="col-sm-12 pad0">
                <div class="col-sm-8 pad-left0">
                	 <div class="mar_bm_65">
                       <h3><strong>Question Number One?</strong></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras lectus est, laoreet a convallis ut, semper et magna. Vivamus ligula lacus, dapibus vitae nibh quis, placerat pulvinar felis.Dolor sit amet, consectetur adipiscing elit. Cras lectus est, laoreet a convallis ut, semper et magna. Vivamus ligula lacus, dapibus vitae nibh quis, placerat pulvinar felis.</p>
                     </div> 
                     
                     <div class="mar_bm_65">
                       <h3><strong>Question Number Two?</strong></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras lectus est, laoreet a convallis ut, semper et magna. Vivamus ligula lacus, dapibus vitae nibh quis, placerat pulvinar felis.Dolor sit amet, consectetur adipiscing elit. Cras lectus est, laoreet a convallis ut, semper et magna. Vivamus ligula lacus, dapibus vitae nibh quis, placerat pulvinar felis.</p>
                     </div> 
                     
                     <div class="mar_bm_65">
                       <h3><strong>Question Number Three?</strong></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras lectus est, laoreet a convallis ut, semper et magna. Vivamus ligula lacus, dapibus vitae nibh quis, placerat pulvinar felis.Dolor sit amet, consectetur adipiscing elit. Cras lectus est, laoreet a convallis ut, semper et magna. Vivamus ligula lacus, dapibus vitae nibh quis, placerat pulvinar felis.</p>
                     </div> 
                     
                     <div class="mar_bm_65">
                       <h3><strong>Question Number Four?</strong></h3>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras lectus est, laoreet a convallis ut, semper et magna. Vivamus ligula lacus, dapibus vitae nibh quis, placerat pulvinar felis.Dolor sit amet, consectetur adipiscing elit. Cras lectus est, laoreet a convallis ut, semper et magna. Vivamus ligula lacus, dapibus vitae nibh quis, placerat pulvinar felis.</p>
                     </div>  
                </div>
                
                <div class="col-sm-4 pad0">
                	<ul class="right_link">
                    	<li>Frequently Asked Questions</li>
                        <li><a>Lorem Ipsum</a></li>
                        <li><a>Lorem Ipsum</a></li>
                        <li><a>Lorem Ipsum</a></li>
                        <li><a>Lorem Ipsum</a></li>
                        <li><a>Lorem Ipsum</a></li>
                    </ul>
                </div>
        	</div>
        </div>
    </div>
</div>