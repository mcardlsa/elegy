Welcome to <?php echo $site_name; ?>,

Celebrate the life of <?php echo $deceased_name; ?>.The best way to contribute and be a part of the memory is through Elegy - the funeral planning and tribute app. To download the iOS version of Elegy and gain all the up to date information, including a schedule, for the funeral - click here.

You are invited to share your memories, whether or not you are able to physically attend or not

Unique Funeral Code <?php echo $invitation_code; ?>
If the above link did not work, please download the Elegy App here<a href="http://www.elegyapp.com">http://www.elegyapp.com</a>

This email was sent via the Elegy App and <a href="http://www.elegyapp.com">http://www.elegyapp.com</a>.  No fees required - simply download the app, input the code and you will have access to all the appropriate information. 