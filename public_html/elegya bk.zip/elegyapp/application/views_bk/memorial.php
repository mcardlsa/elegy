
	<div class="width">
    	<div class="inner_mid mar_tp_230">
        	<h3><strong><?php echo $title; ?></strong></h3>
        	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras lectus est, laoreet a convallis ut, semper et magna. Vivamus ligula lacus, dapibus vitae nibh quis, placerat pulvinar felis.Dolor sit amet, consectetur adipiscing elit. Cras lectus est, laoreet a convallis ut, semper et magna. Vivamus ligula lacus, dapibus vitae nibh quis, placerat pulvinar felis.</p>
            
            <div class="clearfix"></div>
            
            <div class="all_txt_mid register_form">
            	<div class="cl_img"><img src="<?php echo base_url($funeral_detail['profileImage']);?>" width="auto"></div>
                
                <h1><strong><?php echo $funeral_detail['name']; ?></strong></h1>
                <p class="col_txt">Presented by <?php echo $funeral_detail['hostFirstName'] .' '. $funeral_detail['hostLastName'];?></p>
                
                <div class="mar_tp_50 main_txt">
                	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sed scelerisque nulla. Aliquam erat volutpat. Null blandit ligula et libero posuere, id tempus ex cursus. Se augue erat, dictum ac tincidunt et, ullamcorper in quam. Sed ullamcorper vehicula mattis. Donec ac fringilla tortor Proin congue porta ligula eget gravida. Etiam convallis odio cursus magna dictum, ac tristique quam accumsan.</p>
					<p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aenean vel sagittis  orem, ac tempor leo. Quisque eu magna arcu. Sed at sce lerisque libero. Fusce laoreet malesuada nisi et pellente sque.</p>
                </div>
                
				<form class="mar_tp_15">
					<a type="button" class="btn btn-default" href="<?php echo site_url('funeral/create_feed');?>">Continue</a>
				</form>
				
				
            </div>
            
        </div>
    </div>

