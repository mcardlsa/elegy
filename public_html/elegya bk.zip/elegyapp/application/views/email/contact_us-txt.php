Welcome to Elegy

Name : <?php echo $name; ?>
 
Topic :  <?php echo $topic; ?>

Message : <?php echo $message; ?>