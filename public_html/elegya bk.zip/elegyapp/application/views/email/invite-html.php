<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head><title>Welcome to <?php echo $site_name; ?></title></head>
<body>
<div style="max-width: 800px; margin: 0; padding: 30px 0;">
<table width="80%" border="0" cellpadding="0" cellspacing="0">
<tr>
<td width="5%"></td>
<td align="left" width="95%" style="font: 13px/18px Arial, Helvetica, sans-serif;">
<h2 style="font: normal 20px/23px Arial, Helvetica, sans-serif; margin: 0; padding: 0 0 18px; color: black;"></h2>
Please join us as we say goodbye and celebrate the life of <?php echo $deceased_name;?>. The best way to contribute and be a part of the memory is through Elegy - the funeral planning and tribute app. To download the iOS version of Elegy and gain all the up to date information, including a schedule, for the funeral -<a href="http://www.elegyapp.com"> click here.</a> <br><br>

You are invited to share your memories within the Elegy app, whether or not your are able to attend the funeral itself.<br><br>
	
Your Unique Funeral Code: <?php echo $invitation_code; ?>
<br >If the above link did not work, please download the Elegy App here <a href="http://www.elegyapp.com">http://www.elegyapp.com</a> <br>
<br><i>
This email was sent via the Elegy App and <a href="http://www.elegyapp.com">http://www.elegyapp.com</a>.  No fees required - simply download the app, input the code and you will have access to all the appropriate information. <br><br>
</i>
Sincerely,<br>

The Elegy team
</td>
</tr>
</table>
</div>
</body>
</html>