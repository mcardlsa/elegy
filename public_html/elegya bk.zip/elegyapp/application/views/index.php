
<div class="row">
	<div class="banner_container mar_tp_135 position-relative">
        <div class="width">
            <div class="banner_txt_con">
                <div class="banner_txt">
                    <h3>Create a Keepsake</h3>
                    <div class="clearfix"></div>
                    <a class="btn btn-primary" href="#" role="button">Download Now</a>
                </div>
            </div>
        </div>
    <img class="banner_img" src="<?php echo base_url('assets/images/banner_image.jpg');?>" width="100%">
	</div>
</div>

<div class="row">
	<div class="width">
    	<div class="home_mid">
        	<h2><strong>The Funeral Planning and Tribute App</strong></h2>
        	<p class="mar_tp_25 main_txt">Elegy lets you plan a funeral for a loved one. During your time of loss, Elegy is your guiding hand through thefuneral process. Let Elegy show you the steps to create a proper, legal and memorable memorial.</p>
        </div>
    </div>
            
    <div class="border_line"></div>
     
     
     <div class="width">
    	<div class="home_mid">
        	<h3><strong>Focus on what really matters</strong></h3>
        	<div class="clearfix"></div>
            
            <div class="col-sm-12 pad0 mar_tp_25 home_list">
            	<div class="col-sm-4">
                    <h2>Organize.</h2>
                    <p>Unsure how to go about organize a funeral? Find funeral homes, get support for yourself and learn all the steps in the burial process with Elegy.</p>
            	</div>
            
                <div class="col-sm-4">
                   <h2>Organize.</h2>
                   <p>Unsure how to go about organize a funeral? Find funeral homes, get support for yourself and learn all the steps in the burial process with Elegy.</p>
                </div>
            
                <div class="col-sm-4">
                   <h2>Organize.</h2>
                   <p>Unsure how to go about organize a funeral? Find funeral homes, get support for yourself and learn all the steps in the burial process with Elegy.</p>
               </div>
           </div>
           
           <div class="clearfix"></div>
           
           <div class="mar_tp_25">
           		<a class="btn sign_btn" href="<?php echo site_url('user/register');?>" role="button">Sign Up Now</a>
           </div>
        </div>
    </div>           
</div>
