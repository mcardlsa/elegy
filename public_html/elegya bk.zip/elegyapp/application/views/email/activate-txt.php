Welcome to <?php echo $site_name; ?>,

Thanks for joining <?php echo $site_name; ?>. We listed your sign in details below, make sure you keep them safe.
To verify account, please follow this activation code:
<?php echo $activation_code; ?>

Please verify your registration otherwise it will become inactive.


Have fun!
The <?php echo $site_name; ?> Team